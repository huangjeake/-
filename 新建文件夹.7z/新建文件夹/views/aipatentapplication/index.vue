<template>
    <h1>ai-patent-application</h1>
  </template>
  
  <script>
  export default {
  
  }
  </script>
  
  <style>
  
  </style>