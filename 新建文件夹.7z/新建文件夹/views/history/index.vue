<template>
    <div>
      <table>
        <thead>
          <tr>
            <th>序列</th>
            <th>模型</th>
            <th>创建时间</th>
            <th>源文件</th>
            <th>翻译文件</th>
            <th>提示</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in paginatedItems" :key="item.id">
            <td>{{ index + 1 + (currentPage - 1) * perPage }}</td>
            <td>{{ item.model }}</td>
            <td>{{ item.create_time }}</td>
            <td>{{ item.sourcefile }}</td>
            <td>{{ item.translatedfile }}</td>
            <td>{{ item.prompt }}</td>
          </tr>
        </tbody>
      </table>

      <div class="pagination-container">
        <b-pagination
        v-model="currentPage"
        :total-rows="totalRows"
        :per-page="perPage"
        @change="handlePageChange"
        aria-controls="my-table"
        >
        <div>
        <button @click="currentPage--" :disabled="currentPage <= 1">上一页</button>
        <span>Page {{ currentPage }}</span>
        <button @click="currentPage++" :disabled="currentPage >= pageCount">下一页</button>
      </div>
    </b-pagination>
    </div>
    </div> 
</template>
  
<script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        items: [],
        currentPage: 1,
        perPage: 20,
      };
    },
    computed: {
      pageCount() {
        return Math.ceil(this.items.length / this.perPage);
      },
      paginatedItems() {
        const start = (this.currentPage - 1) * this.perPage;
        const end = start + this.perPage;
        return this.items.slice(start, end);
      },
    },
    async created() {
      try {
        const response = await axios.get('YOUR_API_URL');
        this.items = response.data;
      } catch (error) {
        console.error(error);
      }
    },
  };
</script>
  
<style scoped>
  table {
    width: 100%;
    border-collapse: collapse;
  }
  th, td {
    border: 1px solid #000;
    padding: 8px;
    text-align: left;
  }

.pagination-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px; /* 根据需要调整这个值 */
}
</style>
  