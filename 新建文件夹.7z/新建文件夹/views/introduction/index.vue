<template>
  <div class="introduction">
    <img class="background" src="public/backgroud.jpeg" alt="Background">
    <div class="content">
      <h1>Introducing the Copattern for all of you</h1>
      <p>Integrated chatGPT, chatGLM and other AI models are applied to AI chat, 
        document translation, patent drafting, patent evaluation application, etc</p>
        <button>Learn more about Copattern</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Introduction'
}
</script>

<style scoped>
.introduction {
  position: relative;
  width: 100%;
  height: 100vh; /* 调整为需要的高度 */
}

.background {
  position: absolute;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0.5; /* 调整为需要的透明度 */
}

.content {
  position: relative;
  z-index: 1;
  padding: 20px;
  color: white; /* 根据背景图片的颜色，选择适合的文字颜色 */
}

.content h1 {
    color: gray;
}

.content p {
    color: gray;
}

.content button {
    background-color: white;
    color: black;
}
</style>
