<template>
  <h1>ai-patent-drafting</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>