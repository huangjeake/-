<template>
    <div>
      <table>
        <thead>
          <tr>
            <th>用户名</th>
            <th>创建时间</th>
            <th>问题描述</th>
            <th>进展</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in items" :key="item.id">
            <td>{{ item.username }}</td>
            <td>{{ item.createdTime }}</td>
            <td>{{ item.description }}</td>
            <td>{{ item.progress }}</td>
          </tr>
        </tbody>
      </table>
      <div class="pagination-container">
        <b-pagination
        v-model="currentPage"
        :total-rows="totalRows"
        :per-page="perPage"
        @change="handlePageChange"
        aria-controls="my-table"
        >
        <div>
        <button @click="currentPage--" :disabled="currentPage <= 1">上一页</button>
        <span>Page {{ currentPage }}</span>
        <button @click="currentPage++" :disabled="currentPage >= pageCount">下一页</button>
      </div>
    </b-pagination>
    </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        items: []
      };
    },
    async created() {
      try {
        const response = await axios.get('YOUR_API_URL');
        this.items = response.data;
      } catch (error) {
        console.error(error);
      }
    }
  };
  </script>
  
  <style scoped>
  table {
    width: 100%;
    border-collapse: collapse;
  }
  th, td {
    border: 1px solid #000;
    padding: 8px;
    text-align: left;
  }

.pagination-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px; /* 根据需要调整这个值 */
}
  </style>
  