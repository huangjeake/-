<template>
  <h1>ai-chat</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>