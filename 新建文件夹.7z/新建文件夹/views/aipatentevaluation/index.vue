<template>
  <h1>ai-patent-evaluation</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>