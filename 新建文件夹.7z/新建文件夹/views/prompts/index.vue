<template>
    <div class="wrapper">
      <div class="categories">
        <button 
          v-for="(category, index) in categories" 
          :key="index"
          @click="selectedCategory = index">
          {{ category.name }}
        </button>
      </div>
      <div class="industries">
        <button 
          v-for="industry in selectedIndustries" 
          :key="industry"
          @click="addIndustry(industry)">
          {{ industry }}
        </button>
      </div>
      <div class="input-area">
        <input type="text" v-model="inputText" list="industry-options">
        <datalist id="industry-options">
          <option v-for="industry in selectedIndustries" :key="industry" :value="industry"></option>
        </datalist>
      </div>
      <div class="selected-industries">
        <span v-for="(industry, index) in selectedUserIndustries" :key="index">{{ industry }}</span>
      </div>
    </div>
  </template>
  
<script>


export default {
data() {
    return {
        
    categories: [
            {
                name: '互联网',
                industries: ['在线旅游', '在线金融', '在线游戏' /*, ...*/]
            },
            {
                name: '5G',
                industries: ['通信设备', '移动通信', '无线通信' /*, ...*/]
            }
            /*, ...*/
            ], // Your categories and industries here
    selectedCategory: 0,
    selectedUserIndustries: [],
    inputText: ''
    };
},
computed: {
    selectedIndustries() {
    return this.categories[this.selectedCategory].industries;
    }
},
methods: {
    addIndustry(industry) {
    if (!this.selectedUserIndustries.includes(industry)) {
        this.selectedUserIndustries.push(industry);
        this.inputText = '';
    }
    }
},
watch: {
    inputText(newValue) {
    if (this.selectedIndustries.includes(newValue) && !this.selectedUserIndustries.includes(newValue)) {
        this.selectedUserIndustries.push(newValue);
        this.inputText = '';
    }
    }
}
};
  </script>
  
  <style scoped>
  .wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100vh;
    gap: 20px;
  }
  .categories, .industries {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
  }
  .input-area {
    width: 50%;
  }
  .selected-industries {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }
  </style>



