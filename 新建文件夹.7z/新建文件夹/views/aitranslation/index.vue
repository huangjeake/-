<template>
  <div class="grid-container">
    
    <!-- 1st Row: Domain and Industry -->
    <div class="grid-item">
      <div class="row">
      <div class="form-control">
          <label for="domain">领域</label>
          <select v-model="selectedDomain" id="domain">
            <option v-for="domain in domains" :key="domain.id" :value="domain.id">
              {{ domain.name }}
            </option>
          </select>
        </div>
        
        <div class="form-control">
          <label for="industry">行业</label>
          <select v-model="selectedIndustry" id="industry">
            <option v-for="industry in filteredIndustries" :key="industry.id" :value="industry.name">
              {{ industry.name }}
            </option>
          </select>
        </div>
        
      </div>
      
      <!-- Domain and Industry selectors go here -->
    </div>
    
    <!-- 2nd Row: Selected Industry -->
    <div class="grid-item">
      <div class="form-control">
        <input v-model="selectedIndustry" placeholder="选择的行业" readonly>
      </div>
      <!-- Selected Industry input goes here -->
    </div>
    
    <!-- 3rd Row: Language Selection -->
    <div class="grid-item">
      <div class="form-control">
        <label for="language">选择语言</label>
        <select v-model="selectedLanguage" id="language">
          <option v-for="language in languages" :key="language.id" :value="language.id">
            {{ language.name }}
          </option>
        </select>
      </div>
      <!-- Language selector goes here -->
    </div>
    
    <!-- 4th Row: File Upload -->
    <div class="grid-item">
      <div class="form-control">
        <label for="file">上传文件</label>
        <input type="file" id="file" ref="file" v-on:change="handleFileUpload()" multiple accept=".pdf, .docx">
      </div>
      <!-- File upload goes here -->
    </div>
    
    <!-- 5th Row: Translation and Download buttons -->
    <div class="grid-item">
      <div class="row">
      <button v-on:click="translate">翻译</button>
      <button v-on:click="download">下载</button>
    </div>
      
      <!-- Translation and Download buttons go here -->
    </div>
  </div>
</template>

<style>
.grid-container {
display: grid;
grid-template-rows: repeat(5, 1fr);
gap: 20px;
justify-items: center;
align-items: center;
max-width: 600px;
margin: 0 auto;
}

.grid-item {
width: 100%;
}
</style>


<!-- <template>
  <div class="container">
    <div class="sub-container">
      <div class="row">
        <div class="form-control">
          <label for="domain">领域</label>
          <select v-model="selectedDomain" id="domain">
            <option v-for="domain in domains" :key="domain.id" :value="domain.id">
              {{ domain.name }}
            </option>
          </select>
        </div>
        
        <div class="form-control">
          <label for="industry">行业</label>
          <select v-model="selectedIndustry" id="industry">
            <option v-for="industry in filteredIndustries" :key="industry.id" :value="industry.id">
              {{ industry.name }}
            </option>
          </select>
        </div>
      </div>

      <div class="form-control">
        <input v-model="selectedIndustry" placeholder="选择的行业" readonly>
      </div>

      <div class="form-control">
        <label for="language">选择语言</label>
        <select v-model="selectedLanguage" id="language">
          <option v-for="language in languages" :key="language.id" :value="language.id">
            {{ language.name }}
          </option>
        </select>
      </div>

      <div class="form-control">
        <label for="file">上传文件</label>
        <input type="file" id="file" ref="file" v-on:change="handleFileUpload()" multiple accept=".pdf, .docx">
      </div>
    </div>

    <div class="row">
      <button v-on:click="translate">翻译</button>
      <button v-on:click="download">下载</button>
    </div>
  </div>
</template> -->




<script>
import axios from 'axios';
  export default {
    data() {
      return {
        domains: [
          { id: '5g', name: '5G' },
          { id: 'internet', name: '互联网' },
          // 其他领域
        ],
        industries: [
          { id: 'comEquip', domainId: '5g', name: '通信设备' },
          { id: 'mobComm', domainId: '5g', name: '移动通信' },
          // 其他行业
        ],
        languages: [
          { id: 'ch', name: 'Chinese' },
          { id: 'en', name: 'English' },
          { id: 'jp', name: 'Japanese' },
          // 其他语言
        ],
        selectedDomain: null,
        selectedIndustry: null,
        selectedLanguage: null,
        files: null,
        fileUrls: null,
      };
    },
    computed: {
      filteredIndustries() {
        return this.industries.filter(industry => industry.domainId === this.selectedDomain);
      }
    },

    watch: {
    selectedDomain(newDomain) {
        this.selectedIndustry = this.industries.find(industry => industry.domainId === newDomain)?.id || null;
    }
    },

    
    methods: {
        handleFileUpload() {
      this.files = this.$refs.file.files;
    },
    async translate() {
      const formData = new FormData();
      for (let i = 0; i < this.files.length; i++) {
        formData.append('files', this.files[i]);
      }
      formData.append('username', 'Your Username');  // Replace 'Your Username' with actual username

      try {
        const response = await axios.post('/translation/', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        this.fileUrls = response.data.data;
      } catch (error) {
        console.error(error);
      }
    },
    download() {
      const urls = this.fileUrls.split('\n\n');
      urls.forEach(url => {
        const link = document.createElement('a');
        link.href = url;
        link.download = url.split('/').pop();
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      });
    }
    }
  };
</script>


<!-- <style scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}

.sub-container {
  text-align: left;
  width: max-content;
  padding: 0 20px; /* add padding here */
}

.row {
  display: flex;
  justify-content: center;
  gap: 20px;
}

.form-control {
  width: 300px; /* fixed width */
  padding: 10px;
  font-size: 1rem;
  border-radius: 5px;
  border: 1px solid #ced4da;
}

button {
  background-color: #007bff;
  color: white;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}
</style>
 -->

  