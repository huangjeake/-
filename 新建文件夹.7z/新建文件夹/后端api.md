---
title: TCL项目 v1.0.0

> v1.0.0

Base URLs: http://localhost:8080

# <!-- * <a href="http://prod-cn.your-api-server.com">正式环境: http://prod-cn.your-api-server.com</a> -->


## POST 注册

POST /register/

> Body 请求参数

```yaml
username: huanghao
password: huanghao
password2: huanghao
mobile: "13128951234"
allow: "1"

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|
|» username|body|string| 是 |none|
|» password|body|string| 是 |none|
|» password2|body|string| 是 |none|
|» mobile|body|string| 是 |none|
|» allow|body|string| 是 |none|

> 返回示例

> 200 Response

```json
{
  "code": 0,
  "errmsg": "ok"
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 登陆

POST /login/

> Body 请求参数

```yaml
username: huanghao
password: huanghao
remembered: "1"

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|
|» username|body|string| 是 |none|
|» password|body|string| 是 |none|
|» remembered|body|string| 是 |none|

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok"
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 登出

GET /logout/

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok"
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 用户重复

GET /usernames/huanghao/count/

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "count": 1,
    "errmsg": "ok"
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 用户信息

GET /info/

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok",
    "data": {
        "username": "huanghao",
        "email": "",
        "mobile": "13128954444",
        "email_active": false
    }
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 问题

GET /problems/

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|username|query|string| 是 |none|

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok",
    "data": [
        {
            "id": 5,
            "username": "huanghao",
            "create_time": "2021-07-01T10:00:00Z",
            "description": "This is problem 5",
            "status": "going on"
        },
        {
            "id": 9,
            "username": "huanghao",
            "create_time": "2023-06-21T10:00:00Z",
            "description": "我有一个问题",
            "status": "going on"
        }
    ]
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 问题

POST /problems/

> Body 请求参数

```yaml
username: huanghao
create_time: 2022-01-01 12:00:00
description: 我有一个问题
status: gong on

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|
|» username|body|string| 是 |none|
|» create_time|body|string| 是 |none|
|» description|body|string| 是 |none|
|» status|body|string| 是 |none|

> 返回示例

> 200 Response

```json
{
  "code": 0,
  "errmsg": "ok"
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 提示词

GET /prompts/

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok",
    "data": [
        {
            "id": 1,
            "prompt": "How are you feeling today?",
            "category": "Psychology"
        },
        {
            "id": 2,
            "prompt": "What is your current medication?",
            "category": "Medical"
        },
        {
            "id": 3,
            "prompt": "What is your risk tolerance?",
            "category": "Finance"
        },
        {
            "id": 4,
            "prompt": "万物互联",
            "category": "5G"
        }
    ]
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 提示词

POST /prompts/

> Body 请求参数

```yaml
create_time: 2022-01-01 12:00:00
update_time: 2022-01-01 12:00:00
prompt: 你好
category: 问答

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|
|» create_time|body|string| 是 |none|
|» update_time|body|string| 是 |none|
|» prompt|body|string| 是 |none|
|» category|body|string| 是 |none|

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok"
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 模型

GET /models/

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok",
    "data": [
        {
            "id": 1,
            "model": "GPT-3.5",
            "language": "English"
        },
        {
            "id": 2,
            "model": "GPT-4",
            "language": "English"
        },
        {
            "id": 3,
            "model": "BERT",
            "language": "English"
        },
        {
            "id": 4,
            "model": "T5",
            "language": "English"
        },
        {
            "id": 5,
            "model": "RoBERTa",
            "language": "English"
        },
        {
            "id": 6,
            "model": "XLNet",
            "language": "English"
        },
        {
            "id": 7,
            "model": "文心一言",
            "language": "Chinese"
        },
        {
            "id": 8,
            "model": "讯飞星火",
            "language": "Chinese"
        },
        {
            "id": 9,
            "model": "盘古",
            "language": "Chinese"
        },
        {
            "id": 10,
            "model": "azure",
            "language": "English"
        },
        {
            "id": 11,
            "model": "test",
            "language": "English"
        }
    ]
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 模型

POST /models/

> Body 请求参数

```yaml
create_time: 2022-01-01 12:00:00
update_time: 2022-01-01 12:00:00
model: chatgpt3.5
language: english

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|
|» create_time|body|string| 是 |none|
|» update_time|body|string| 是 |none|
|» model|body|string| 是 |none|
|» language|body|string| 是 |none|

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok"
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 历史记录

POST /browse_histories/

> Body 请求参数

```yaml
username: huanghao
history_record: "{\"model\":\"chatgpt3.5\",\r

  \"create_time\":\"2022-01-10 09:00:00\",\r

  \"sourcefile\":\"test.pdf\",\r

  \"translatedfile\":\"translated_test.pdf\",\r

  \"prompt\":\"你好\",\r

  }"

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|
|» username|body|string| 是 |none|
|» history_record|body|string| 是 |none|

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok"
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 历史记录

GET /browse_histories/

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|username|query|string| 是 |none|

> 返回示例

> 200 Response

```json
{
    "code": 0,
    "errmsg": "ok",
    "data": {
        "1687343813.6998327": "{\"time\":2023-06-21 11:45:18, \n\"sourcefile\":\"test.pdf\",\n\"translatedfile\":\"translated_test.pdf\",\n\"model\":\"ChatGTP3.5\",\n\"prompt\":\"这是一个测试\"\n}"
    }
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 翻译

POST /translation/

> Body 请求参数

```yaml
username: huanghao
"files[]":
  - file://C:\Users\Administrator\Desktop\test.pdf
  - file://C:\Users\Administrator\Desktop\test2.pdf

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|
|» username|body|string| 是 |none|
|» files[]|body|string(binary)| 是 |none|

> 返回示例

> 200 Response

```json
{ "code": 0,
    "errmsg": "ok",
    "data": "C:\\Users\\ex_hao.huang\\Desktop\\tcl-projects\\llm\\files/huanghao/download/test_translated .txt\n\nC:\\Users\\ex_hao.huang\\Desktop\\tcl-projects\\llm\\files/huanghao/download/test1_translated .txt"
    }
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构


